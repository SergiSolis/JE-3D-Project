BRUNO SÁNCHEZ
email: bruno.sanchez01@estudiant.upf.edu

SERGI SOLÍS
email: sergi.solis01@estudiant.upf.edu

Los principales problemas están explicados en el vídeo :)

https://youtu.be/CXurPBCP6K4